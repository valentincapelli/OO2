package ar.edu.unlp.info.oo2.facturacion_llamadas;

import java.util.TreeSet;
import java.util.ArrayList;
import java.util.Random;
import java.util.SortedSet;

public class GestorNumerosDisponibles {
	private SortedSet<String> lineas = new TreeSet<String>();
	private String tipoGenerador = "ultimo";

	public SortedSet<String> getLineas() {
		return lineas;
	}

	public String obtenerNumeroLibre() {
		String linea;
		switch (tipoGenerador) {
			case "ultimo":
				linea = lineas.last();
				lineas.remove(linea);
				return linea;
			case "primero":
				linea = lineas.first();
				lineas.remove(linea);
				return linea;
			case "random":
				linea = new ArrayList<String>(lineas)
						.get(new Random().nextInt(lineas.size()));
				lineas.remove(linea);
				return linea;
		}
		return null;
	}

	public void cambiarTipoGenerador(String valor) {
		this.tipoGenerador = valor;
	}
	
	public boolean buscar(String string) {
		return this.lineas.contains(string);
	}
	
	public void agregarNumero(String string) {
		this.lineas.add(string);
	}
	
	public boolean agregarNumeroTelefono(String str) {
		boolean encontre = this.buscar(str);
		if (!encontre) {
			this.agregarNumero(str);
			encontre= true;
		}
		else {
			encontre= false;
		}
		return encontre;
	}
	
}
